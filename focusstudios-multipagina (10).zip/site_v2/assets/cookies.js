(function () {
  var KEY = 'focus_cookie_consent';
  // If a choice already exists, do nothing.
  try {
    if (localStorage.getItem(KEY)) return;
  } catch (e) { /* localStorage may be blocked; show banner anyway */ }

  function save(value) {
    try { localStorage.setItem(KEY, value); } catch (e) {}
    var b = document.getElementById('cookie-banner');
    if (b) {
      b.style.opacity = '0';
      b.style.transform = 'translateY(20px)';
      setTimeout(function () { if (b && b.parentNode) b.parentNode.removeChild(b); }, 350);
    }
    // Placeholder: load analytics only if accepted all.
    if (value === 'all') {
      // e.g. cargar Google Analytics aquí cuando lo tengas
    }
  }

  function build() {
    var banner = document.createElement('div');
    banner.id = 'cookie-banner';
    banner.setAttribute('role', 'dialog');
    banner.setAttribute('aria-label', 'Aviso de cookies');
    banner.innerHTML =
      '<div class="cb-inner">' +
        '<div class="cb-text">' +
          '<strong>Usamos cookies</strong>' +
          '<p>Utilizamos cookies propias y de terceros para mejorar tu experiencia y analizar el tr\u00e1fico. ' +
          'Puedes aceptarlas todas o quedarte solo con las esenciales. ' +
          '<a href="cookies.html">M\u00e1s informaci\u00f3n</a>.</p>' +
        '</div>' +
        '<div class="cb-actions">' +
          '<button type="button" class="cb-btn cb-essential" id="cb-essential">Solo esenciales</button>' +
          '<button type="button" class="cb-btn cb-accept" id="cb-accept">Aceptar todas</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(banner);
    document.getElementById('cb-accept').addEventListener('click', function () { save('all'); });
    document.getElementById('cb-essential').addEventListener('click', function () { save('essential'); });
    // trigger entrance transition
    requestAnimationFrame(function () {
      requestAnimationFrame(function () { banner.classList.add('cb-show'); });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', build);
  } else {
    build();
  }
})();
